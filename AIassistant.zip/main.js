// VoiceFlow AI - Main JavaScript File
// Handles all interactive features and animations

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initializeHeroAnimations();
    initializeVoiceDemo();
    initializeVoiceCarousel();
    initializePricingToggle();
    initializeROICalculator();
    initializeIndustryShowcase();
    initializeMetricCounters();
    initializeScrollAnimations();
});

// Hero Section Animations
function initializeHeroAnimations() {
    // Typed.js for hero text
    if (document.getElementById('typed-text')) {
        new Typed('#typed-text', {
            strings: [
                'That Never Sleeps',
                'That Scales Infinitely', 
                'That Converts Better',
                'That Saves You Money'
            ],
            typeSpeed: 80,
            backSpeed: 60,
            backDelay: 2000,
            loop: true,
            showCursor: true,
            cursorChar: '|'
        });
    }

    // Fade in hero content
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        setTimeout(() => {
            heroContent.classList.add('fade-in');
        }, 500);
    }
}

// Voice Demo Interface
function initializeVoiceDemo() {
    const startCallBtn = document.getElementById('start-call');
    const endCallBtn = document.getElementById('end-call');
    const transcriptDiv = document.getElementById('transcript');
    const waveformDiv = document.getElementById('waveform');
    
    let currentCall = null;
    let selectedCompany = 'medical';
    let selectedVoice = 'sarah';
    
    // Company type selection
    document.querySelectorAll('.company-type').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.company-type').forEach(b => {
                b.classList.remove('border-red-400');
                b.classList.add('border-gray-200');
            });
            this.classList.remove('border-gray-200');
            this.classList.add('border-red-400');
            selectedCompany = this.dataset.type;
        });
    });
    
    // Voice personality selection
    document.querySelectorAll('.voice-personality').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.voice-personality').forEach(b => {
                b.classList.remove('border-red-400');
                b.classList.add('border-gray-200');
            });
            this.classList.remove('border-gray-200');
            this.classList.add('border-red-400');
            selectedVoice = this.dataset.voice;
        });
    });
    
    // Start call functionality
    if (startCallBtn) {
        startCallBtn.addEventListener('click', function() {
            startCall();
        });
    }
    
    // End call functionality
    if (endCallBtn) {
        endCallBtn.addEventListener('click', function() {
            endCall();
        });
    }
    
    function startCall() {
        startCallBtn.disabled = true;
        startCallBtn.classList.add('opacity-50', 'cursor-not-allowed');
        endCallBtn.disabled = false;
        endCallBtn.classList.remove('opacity-50', 'cursor-not-allowed');
        
        // Start waveform animation
        startWaveformAnimation();
        
        // Simulate call transcript
        simulateCallTranscript();
    }
    
    function endCall() {
        startCallBtn.disabled = false;
        startCallBtn.classList.remove('opacity-50', 'cursor-not-allowed');
        endCallBtn.disabled = true;
        endCallBtn.classList.add('opacity-50', 'cursor-not-allowed');
        
        // Stop waveform animation
        stopWaveformAnimation();
        
        // Add end call message
        if (transcriptDiv) {
            transcriptDiv.innerHTML += `
                <div class="text-center text-gray-500 mt-4">
                    <em>Call ended. Total duration: 2 minutes 34 seconds</em>
                </div>
            `;
        }
    }
    
    function startWaveformAnimation() {
        if (waveformDiv) {
            waveformDiv.innerHTML = '<div class="w-full h-full flex items-center justify-center"><div class="flex space-x-1"><div class="w-1 h-8 bg-white rounded animate-pulse"></div><div class="w-1 h-12 bg-white rounded animate-pulse" style="animation-delay: 0.1s"></div><div class="w-1 h-16 bg-white rounded animate-pulse" style="animation-delay: 0.2s"></div><div class="w-1 h-12 bg-white rounded animate-pulse" style="animation-delay: 0.3s"></div><div class="w-1 h-8 bg-white rounded animate-pulse" style="animation-delay: 0.4s"></div></div></div>';
        }
    }
    
    function stopWaveformAnimation() {
        if (waveformDiv) {
            waveformDiv.innerHTML = '<div class="w-full h-full flex items-center justify-center text-white font-medium">Click "Start Call" to see live audio visualization</div>';
        }
    }
    
    function simulateCallTranscript() {
        const transcripts = {
            medical: {
                sarah: [
                    { speaker: 'AI', text: 'Thank you for calling Metro Medical Center. This is Sarah, how may I help you today?' },
                    { speaker: 'Caller', text: 'Hi, I need to schedule an appointment for a check-up.' },
                    { speaker: 'AI', text: 'I\'d be happy to help you schedule a check-up. Do you have a preferred doctor or date in mind?' },
                    { speaker: 'Caller', text: 'I usually see Dr. Johnson. Is she available next Tuesday?' },
                    { speaker: 'AI', text: 'Let me check Dr. Johnson\'s availability for next Tuesday. I see she has openings at 10:30 AM and 2:15 PM. Which time works better for you?' }
                ]
            },
            legal: {
                mike: [
                    { speaker: 'AI', text: 'Law Offices of Smith & Associates. This is Mike speaking, how can I assist you today?' },
                    { speaker: 'Caller', text: 'I need help with a business contract dispute.' },
                    { speaker: 'AI', text: 'I understand you need assistance with a business contract dispute. Let me gather some initial information. What type of business are you in?' },
                    { speaker: 'Caller', text: 'I run a small consulting firm. The client won\'t pay their invoice.' },
                    { speaker: 'AI', text: 'Thank you for that information. I\'ll schedule a consultation with our business litigation attorney. When would be convenient for you?' }
                ]
            }
        };
        
        const selectedTranscript = transcripts[selectedCompany]?.[selectedVoice] || transcripts.medical.sarah;
        
        if (transcriptDiv) {
            transcriptDiv.innerHTML = '';
            
            selectedTranscript.forEach((line, index) => {
                setTimeout(() => {
                    const messageDiv = document.createElement('div');
                    messageDiv.className = `mb-2 ${line.speaker === 'AI' ? 'text-blue-600' : 'text-gray-700'}`;
                    messageDiv.innerHTML = `<strong>${line.speaker}:</strong> ${line.text}`;
                    transcriptDiv.appendChild(messageDiv);
                    transcriptDiv.scrollTop = transcriptDiv.scrollHeight;
                }, index * 2000);
            });
        }
    }
}

// Voice Personality Carousel
function initializeVoiceCarousel() {
    if (document.getElementById('voice-carousel')) {
        new Splide('#voice-carousel', {
            type: 'loop',
            perPage: 3,
            perMove: 1,
            gap: '2rem',
            autoplay: true,
            interval: 4000,
            pauseOnHover: true,
            breakpoints: {
                1024: {
                    perPage: 2,
                },
                640: {
                    perPage: 1,
                }
            }
        }).mount();
    }
}

// Pricing Toggle
function initializePricingToggle() {
    const toggles = document.querySelectorAll('.feature-toggle');
    const priceAmounts = document.querySelectorAll('.price-amount');
    const pricePeriods = document.querySelectorAll('.price-period');
    
    toggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const period = this.dataset.period;
            
            // Update toggle states
            toggles.forEach(t => {
                t.classList.remove('active');
            });
            this.classList.add('active');
            
            // Update prices
            const prices = {
                monthly: { starter: 49, professional: 149, enterprise: 299 },
                annual: { starter: 39, professional: 119, enterprise: 239 }
            };
            
            priceAmounts.forEach((amount, index) => {
                const plans = ['starter', 'professional', 'enterprise'];
                const plan = plans[index % 3];
                amount.textContent = prices[period][plan];
            });
            
            // Update billing period text
            pricePeriods.forEach(period => {
                period.textContent = period === 'monthly' ? 'monthly' : 'annually';
            });
        });
    });
}

// ROI Calculator
function initializeROICalculator() {
    const callVolumeSlider = document.getElementById('call-volume');
    const receptionistCostSlider = document.getElementById('receptionist-cost');
    const hoursOperationSelect = document.getElementById('hours-operation');
    
    const callVolumeValue = document.getElementById('call-volume-value');
    const receptionistCostValue = document.getElementById('receptionist-cost-value');
    const monthlySavings = document.getElementById('monthly-savings');
    const annualSavings = document.getElementById('annual-savings');
    const roiPercentage = document.getElementById('roi-percentage');
    
    function updateCalculator() {
        if (!callVolumeSlider || !receptionistCostSlider) return;
        
        const callVolume = parseInt(callVolumeSlider.value);
        const receptionistCost = parseInt(receptionistCostSlider.value);
        const hoursOperation = parseInt(hoursOperationSelect.value);
        
        // Update display values
        if (callVolumeValue) callVolumeValue.textContent = callVolume;
        if (receptionistCostValue) receptionistCostValue.textContent = `$${receptionistCost.toLocaleString()}`;
        
        // Calculate VoiceFlow AI cost (estimated)
        const voiceflowBaseCost = 149; // Professional plan
        const additionalMinutes = Math.max(0, callVolume - 2000);
        const voiceflowCost = voiceflowBaseCost + (additionalMinutes * 0.05);
        
        // Calculate savings
        const monthlySave = receptionistCost - voiceflowCost;
        const annualSave = monthlySave * 12;
        const roi = Math.round((monthlySave / receptionistCost) * 100);
        
        // Update savings display
        if (monthlySavings) monthlySavings.textContent = Math.round(monthlySave).toLocaleString();
        if (annualSavings) annualSavings.textContent = Math.round(annualSave).toLocaleString();
        if (roiPercentage) roiPercentage.textContent = Math.max(0, roi);
    }
    
    if (callVolumeSlider) {
        callVolumeSlider.addEventListener('input', updateCalculator);
    }
    if (receptionistCostSlider) {
        receptionistCostSlider.addEventListener('input', updateCalculator);
    }
    if (hoursOperationSelect) {
        hoursOperationSelect.addEventListener('change', updateCalculator);
    }
    
    // Initial calculation
    updateCalculator();
}

// Industry Showcase
function initializeIndustryShowcase() {
    const industryCards = document.querySelectorAll('.industry-card');
    const showcases = document.querySelectorAll('.industry-showcase');
    
    industryCards.forEach(card => {
        card.addEventListener('click', function() {
            const industry = this.dataset.industry;
            
            // Update active card
            industryCards.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding showcase
            showcases.forEach(showcase => {
                showcase.classList.add('hidden');
            });
            
            const targetShowcase = document.getElementById(`${industry}-showcase`);
            if (targetShowcase) {
                targetShowcase.classList.remove('hidden');
                
                // Animate showcase appearance
                anime({
                    targets: targetShowcase,
                    opacity: [0, 1],
                    translateY: [20, 0],
                    duration: 600,
                    easing: 'easeOutQuart'
                });
            }
        });
    });
}

// Metric Counters Animation
function initializeMetricCounters() {
    const counters = document.querySelectorAll('.metric-counter');
    
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px 0px -100px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.dataset.target);
                
                anime({
                    targets: counter,
                    innerHTML: [0, target],
                    duration: 2000,
                    round: 1,
                    easing: 'easeOutQuart'
                });
                
                observer.unobserve(counter);
            }
        });
    }, observerOptions);
    
    counters.forEach(counter => observer.observe(counter));
}

// Scroll Animations
function initializeScrollAnimations() {
    // Animate elements on scroll
    const animateElements = document.querySelectorAll('.voice-card, .pricing-card, .scenario-card');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                anime({
                    targets: entry.target,
                    opacity: [0, 1],
                    translateY: [30, 0],
                    duration: 800,
                    easing: 'easeOutQuart',
                    delay: Math.random() * 200
                });
                
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Set initial state
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
    });
    
    animateElements.forEach(el => observer.observe(el));
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Mobile menu toggle (if needed)
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('hidden');
    }
}

// Voice sample playback (placeholder)
function playVoiceSample(voiceId) {
    // This would integrate with actual audio playback
    console.log(`Playing voice sample for: ${voiceId}`);
    
    // Show temporary feedback
    const button = event.target;
    const originalText = button.textContent;
    button.textContent = 'Playing...';
    button.disabled = true;
    
    setTimeout(() => {
        button.textContent = originalText;
        button.disabled = false;
    }, 3000);
}

// Form handling
function handleFormSubmit(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mt-4';
            successMessage.textContent = 'Thank you! We\'ll be in touch soon.';
            
            form.appendChild(successMessage);
            form.reset();
            
            // Remove message after 5 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 5000);
        });
    }
}

// Initialize form handling
handleFormSubmit('contact-form');
handleFormSubmit('demo-form');

// Performance monitoring
const performanceObserver = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
        if (entry.entryType === 'navigation') {
            console.log('Page load time:', entry.loadEventEnd - entry.loadEventStart, 'ms');
        }
    }
});

if (typeof PerformanceObserver !== 'undefined') {
    performanceObserver.observe({ entryTypes: ['navigation'] });
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
});

// Export functions for external use
window.VoiceFlowAI = {
    playVoiceSample,
    toggleMobileMenu,
    initializeVoiceDemo,
    initializePricingToggle
};